# chinese-address-generator (中国地址随机生成器)
## 数据集
数据来源：国家统计局——`2023年度全国统计用区划代码和城乡划分代码`的权威数据。  
Link: ***https://www.stats.gov.cn/sj/tjbz/tjyqhdmhcxhfdm/2023/index.html***

## 使用方法
### 通过pip安装
```bash
pip install chinese-address-generator
```
### Project中使用
#### 导入生成器
```bash
from chinese_address_generator import generator
```
#### 生成一级地址：[省、自治区、直辖市]
```bash
generator.generatelevel1() #返回一级地址字符串

$ 天津市 120000
```
#### 生成二级地址：[省、自治区、直辖市]-[市、地区]
```bash
generator.generatelevel2() #返回二级字符串

$ 江苏省南京市 320100
```
#### 生成三级地址：[省、自治区、直辖市]-[市、地区]-[区、县]
```bash
generator.generatelevel3() #返回三级字符串

$ 陕西省西安市阎良区 610114
```
#### 生成四级地址：[省、自治区、直辖市]-[市、地区]-[区、县]-[乡、镇、街道]
```bash
generator.generatelevel4() #返回四级字符串

$ 江西省南昌市红谷滩区龙兴街道 360113
```
## 补充说明
### 查看原始数据
```bash
import chinese_address_generator
chinese_address_generator.level3_list #三级地址原始文件
chinese_address_generator.level4_list #四级地址原始文件
```

